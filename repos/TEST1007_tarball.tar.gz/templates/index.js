module.exports = function Templates() {
this.speakers = require('./speakers.js');
this.topics = require('./topics.js');
this.email_addresses = require('./email_addresses.js');
this.topics = require('./topics.js');
this.speakers = require('./speakers.js');
this.details = require('./details.js');

}