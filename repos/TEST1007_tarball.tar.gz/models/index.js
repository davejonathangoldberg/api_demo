module.exports = function Models() {
this.speakers = require('./speakers');
this.topics = require('./topics');
this.email_addresses = require('./email_addresses');
this.topics = require('./topics');
this.speakers = require('./speakers');
this.details = require('./details');

}